#include "main.h"

void controlTrigger();