#include "main.h"

void setRoller(int power);

void controlRoller();