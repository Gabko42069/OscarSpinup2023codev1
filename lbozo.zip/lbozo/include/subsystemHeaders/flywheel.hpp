#include "main.h"

void setPultyPoo(int power);

void controlCata();