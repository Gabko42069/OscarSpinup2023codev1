#include "main.h" 

// MOTORS
extern Motor frontRight;
extern Motor backRight;
extern Motor frontLeft;
extern Motor backLeft;
extern Motor middleLeft;
extern Motor middleRight; 

extern Motor catapult;
extern Motor intake;

// PNEUMATICS
extern ADIPort trigger;
extern ADIPort button; 

// MISC
extern Imu gyro;
extern Controller controller;

// MATH
#define driveGearRatio 2.3333
#define wheelDiameter 4

// PORTS
#define middleRightPort 2 
#define frontRightPort 6 // right
#define backRightPort 9 // right
#define frontLeftPort 21 // right 
#define backLeftPort 11 // right 
#define middleLeftPort 8 // right 
#define intakePort 7
#define catapultPort 3
#define buttonPort 'a'
#define triggerPort 'F'