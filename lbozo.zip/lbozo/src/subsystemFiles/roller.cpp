#include "main.h"

void setRoller(int power)
{
    intake = power;
}

void controlRoller()
{
    if (controller.get_digital(DIGITAL_X) || controller.get_digital(DIGITAL_R1) )
    {
        setRoller(127);
    }
    else if (controller.get_digital(DIGITAL_B) || controller.get_digital(DIGITAL_R2) )
    {
        setRoller(-127);
    }
    else
    {
        setRoller(0);
    }
}