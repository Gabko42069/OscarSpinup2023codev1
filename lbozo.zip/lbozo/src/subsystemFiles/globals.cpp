#include "main.h"
#include "pros/motors.h"

Motor frontLeft(frontLeftPort, E_MOTOR_GEARSET_06);
Motor backLeft(backLeftPort, E_MOTOR_GEARSET_06);
Motor middleLeft( middleLeftPort, E_MOTOR_GEARSET_06); 

Motor frontRight(frontRightPort, E_MOTOR_GEARSET_06);
Motor backRight(backRightPort, E_MOTOR_GEARSET_06);
Motor middleRight(middleRightPort, E_MOTOR_GEARSET_06);

Motor catapult(catapultPort, E_MOTOR_GEARSET_06, false);
Motor intake(intakePort, E_MOTOR_GEARSET_06);

ADIPort trigger(triggerPort, ADI_DIGITAL_OUT);
ADIPort button(buttonPort, ADI_DIGITAL_IN); 
// Imu gyro(gyroPort);

Controller controller(E_CONTROLLER_MASTER);
