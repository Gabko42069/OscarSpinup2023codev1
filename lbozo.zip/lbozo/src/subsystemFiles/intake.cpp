#include "main.h"
// #include "pros/misc.h"

void setIntake(int power)
{
    intake = power;
}

void controlIntake()
{
    if(controller.get_digital(DIGITAL_B))
    {
        setIntake(127);
    }else if (controller.get_digital(DIGITAL_A)) {
        setIntake(-127);
    } else {
        setIntake(0);
    }
    
    //int power = -127 * (controller.get_digital(DIGITAL_R2) - controller.get_digital(DIGITAL_R1));
    

}