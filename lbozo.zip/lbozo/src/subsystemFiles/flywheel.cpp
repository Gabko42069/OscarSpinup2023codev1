#include "main.h"
#include "pros/misc.h"

void setPultyPoo(int power)
{
    catapult = power;  
}

void controlCata()
{
    if(button.get_value())
    {
        setPultyPoo(0);
    } 
    
    if(controller.get_digital(DIGITAL_L2))
    {
       
        setPultyPoo(127);
        
    }
    
    //setPultyPoo(-127 * (controller.get_digital(DIGITAL_L2) - controller.get_digital(DIGITAL_L1)));
}
